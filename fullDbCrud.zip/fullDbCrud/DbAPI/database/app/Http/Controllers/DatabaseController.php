<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use  Illuminate\Support\Collection;
use Illuminate\Http\Request;

class DatabaseController extends Controller
{
    public function Datausecontroller(){
        return 'Hello thon';
    }


    public function indexdata(){
     $data =   DB::table('userid')->find(1);
     foreach($data as $showdata){
        echo $showdata;
     }
    }

    public function datefunction(){
        $price = DB::table('userid')->max('Price');

       echo $price;
    }

    public function caldata(){
        $users = DB::table('userid')->count();
        echo $users;
    }

    
    
}
