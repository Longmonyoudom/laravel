<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class StatementsController extends Controller
{
    public function statement()
    {
        /*
        $users = DB::table('productuser')
        ->select('name', 'email as user_email')
        ->get();
        echo $users;
        echo "<br />";
        */

        $users = DB::table('tbluser')
            ->select('userid', 'username as user_username')
            ->get();
        //  echo $users;
        foreach ($users as $data) {
            echo $data->userid;
            echo $data->user_username;
            echo "<br />";
        }
    }

    public function distinct(){
        $users = DB::table('userid')->distinct()->get();
        echo $users;
    }
}
