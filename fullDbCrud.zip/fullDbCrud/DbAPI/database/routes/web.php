<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DatabaseController;
use App\Http\Controllers\StatementsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//--------------Please input---------------------//
Route::get('/form',[UserController::class,"controlleruser"] )->name("pageform");

Route::get('/book',[DatabaseController::class,"Datausecontroller"]);
Route::post('/uadd',[UserController::class,"showdata"]);

Route::post('/del',[UserController::class,"remove"]);


Route::post('/update',[UserController::class,"updatenew"]);

//--------------Please input---------------------//


Route::get('/data',[DatabaseController::class,"indexdata"]);
Route::get('/cal',[DatabaseController::class,"caldata"]);

Route::get('/datashow',[DatabaseController::class,"datefunction"]);

Route::get('/name',[DatabaseController::class,"aggregate"]);

//----------------------please statement for juery builder---------------//

Route::controller(StatementsController::class)->group(function () {
    Route::get('/userStatement',[StatementsController::class,'statement']);
    Route::get('/userdistinct',[StatementsController::class,'distinct']);


});


