<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous">
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/cesiumjs/1.78/Build/Cesium/Cesium.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM="
        crossorigin="anonymous"></script>
    <title>Document</title>
</head>

<body>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });


        $(document).ready(function() {
            $("#add").click(function() {

                
                $("#addeven").modal("show");
            })


            // get all values from element form

            $("#btnsave").click(function() {
                var username = $("#txtusername").val();
                var userpassword = $("#txtuserpassword").val();
                var status = $("#slstatus").val();
                // alert(username+""+userpassword+""+status+"")
                if (username == "" || userpassword == "") {
                    $("#red").html("Empty user or password");
                    $("#red").css({
                        color: "red"
                    })
                } else {
                    $.post('/uadd', {
                        txtuser: username,
                        txtpass: userpassword,
                        slstatus: status
                    }, function(result) {
                        //  window.location.href="<?php echo e(route('pageform')); ?>";
                        Swal.fire(result);
                    });
                }


            });
            // get id from html 
            $("#tbluser tr").on("click",'.del', function() {
                var current_row = $(this).closest("tr");
               

                var userid = current_row.find("td").eq(0).text();
                var username = current_row.find("td").eq(1).text();
                
                $("#delectmodal").modal("show");
                  $("#olduser").html(username);
                  $("#txtnumber").val(userid);  
            });
            // function delete for laravel 
            $("#btndel").click(function(){
              var userid=$("#txtnumber").val();
              $.post('/del',{userdb:userid},function(data){
                   alert(data);
                   window.location.href="<?php echo e(route('pageform')); ?>"
              })
            })
            // function delecte for laravel
            // for edite for laravel 
            $("#tbluser tr").on("click",'.update', function() {
                var current_row = $(this).closest("tr");
                var useridnew = current_row.find("td").eq(0).text();
                var nameupdate = current_row.find("td").eq(1).text();
                var passwordupdate = current_row.find("td").eq(3).text();
                $("#modalupdate").modal("show");
                var     idwhereupdate=$("#idnameuser").val(useridnew);

            });
            //  push to controller for laravel for database
            $("#btnupdate").click(function(){
           var      updateuservalues=$("#updateusername").val();
            var     updateuserpassvalues=$("#updateuserpassword").val();
            var     idwhereupdate=$("#idnameuser").val();
              $.post('/update',{ idupdatedb:idwhereupdate,updateuser:updateuservalues, updatepassworduser:updateuserpassvalues},function(result){
               if(result==1){
                 window.location.href="<?php echo e(route('pageform')); ?>";
               }
              });
            })

        })
    </script>
    <div class="container">
        <div> <a href="#" id="add">Add to object</a></div>
        <div class="row">
            
            <table class="table-bordered " id="tbluser">
                <tr class="table-primary">
                    <td>User id</td>
                    <td>User name</td>
                    <th>Status </th>
                    <td>Action</td>
                </tr>
                <?php $__currentLoopData = $userdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td> <?php echo e($obj->userid); ?></td>
                        <td> <?php echo e($obj->username); ?></td>
                        <td> <?php echo e($obj->status); ?></td>
                        <td class="dropdown-menu"> <?php echo e($obj->password); ?></td>
                        <td>  <a href="#" class="update">Edite </a> | <a href="#" class="del">delect</a></td>
                    </tr>

                    <br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

            
        </div>
    </div>

    <?php echo e($userdata->links()); ?>


    


    <div class="modal fade" id="addeven" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">New message</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" accept="/uadd">
                        <?php echo csrf_field(); ?>
                        <p id="red"></p>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Username for user</label>
                            <input type="text" class="form-control" id="txtusername">
                        </div>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">password for user</label>
                            <input type="password" class="form-control" id="txtuserpassword">
                        </div>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Starte for user</label>
                            <select id="slstatus" class="form-select">
                                <option value="0">active</option>
                                <option value="1">Inactived</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="btnsave">Save</button>
                </div>
            </div>
        </div>
    </div>
    
    

    <div class="modal fade" id="delectmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <h1 class="modal-title fs-5" id="exampleModalLabel">New message</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <form action="/del" method="POST">
                <div class="modal-body">
                  <input type="text" id="txtnumber" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2"><br>
                  <p>Do you want to delete this user ?(<span id="olduser"></span>)</p>
                </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary" id="btndel">Save</button>
              </div>
            </form>
          </div>
      </div>
  </div>
        
        

        <div class="modal fade" id="modalupdate" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
              <div class="modal-content">
                  <div class="modal-header">
                      <h1 class="modal-title fs-5" id="exampleModalLabel">please update user for all </h1>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      <form method="POST" accept="/update">
                          <?php echo csrf_field(); ?>
                          <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">id  for user</label>
                            <input type="text" class="form-control" id="idnameuser">
                        </div>
                          <div class="mb-3">
                              <label for="recipient-name" class="col-form-label">Username for user</label>
                              <input type="text" class="form-control" id="updateusername">
                          </div>
                          <div class="mb-3">
                              <label for="recipient-name" class="col-form-label">password for user</label>
                              <input type="password" class="form-control" id="updateuserpassword">
                          </div>
                      </form>
                  </div>
                  <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="button" class="btn btn-primary" id="btnupdate">Save</button>
                  </div>
              </div>
          </div>
      </div>
         
</body>

</html>
<?php /**PATH D:\laravel\DbAPI\database\resources\views/user.blade.php ENDPATH**/ ?>